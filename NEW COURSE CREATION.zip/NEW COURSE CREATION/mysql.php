<?php
	include_once 'header.php';
	include_once 'includes/dbh_inc.php';
	
	if(!isset($_SESSION['u_id']))
	{
		header("Location: index.php");
		exit();
	}
	
	
	
?>



<div class="row" style="background-color:#ffffff;">
  <div id="container" class="row">
    <!-- Main image on page -->
	
	<?php
	//###################assign given course_id here##############################
	$c_id=1;
	$u_id=$_SESSION['u_id'];

	$sql="select * from enrolled_for where u_id='$u_id' and c_id='$c_id';";
	$resultx=mysqli_query($conn , $sql);
	$result_check=mysqli_num_rows($resultx);
	
	if(!$result_check >0)
	{
	//if not enrolled then show enrollment form
		echo '<iframe src="courses/mysql/desc.php" name="iframe_a" style="border:none;" height="300" width="600"></iframe>';
	
		exit();
	}
	?>
    
	<div id="content" style="width: 300px;">
          <aside id="left_column">
      <h2 class="title">Mysql</h2>
      <nav>
        <ul class="list-group">
		<!--############## arrange path and modules here ##############-->
          <li><a href="courses/mysql/intro.php" target="iframe_a" class="list-group-item">Introduction</a></li>
          <li><a href="courses/mysql/ddl.php" target="iframe_a" class="list-group-item">DDL</a></li>
          <li><a href="courses/mysql/dml.php" target="iframe_a" class="list-group-item">DML</a></li>
		  <li><a href="courses/mysql/joins.php" target="iframe_a" class="list-group-item">Joins</a></li>
          <li class="last"><a href="courses/mysql/test.php" target="iframe_a" class="list-group-item">Test</a></li>
        </ul>
      </nav>
    </div>

	<div style="height:59px;"></div>

	<div class="col-md- col-md-offset-1">
	
	<iframe src="courses/mysql/intro.php" name="iframe_a" style="border:none;" height="800" width="600"></iframe>
	
	
   <!--main ends-->
   </div>
   </div>
</div>



<?php
	include_once 'footer.php';
?>