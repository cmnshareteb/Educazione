 <?php
 
 if(!isset($_POST['submit']))
 {
	header("Location: ../../index.php");
	exit();
 }
	include_once '../../includes/dbh_inc.php';
	$c_id=$_POST['c_id'];
	$u_id=$_POST['u_id'];
	
	//inserting user into database
	$sql="insert into enrolled_for (u_id,c_id) values ('$u_id','$c_id');";
	$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
	
	echo '<h4>Enroll successful </h4>';
	echo '<h4>Please reload the page now to access contents.</h4>';
	
	