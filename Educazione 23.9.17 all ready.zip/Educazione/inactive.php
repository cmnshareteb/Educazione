<?php
	include_once 'includes/dbh_inc.php';
	session_start();
	
	echo '<link rel="stylesheet" href="assets/css/bootstrap.min.css" />';
?>	
	

 <span>
			        
						<?php

						//running query now
							$sql="SELECT * FROM courses WHERE c_status='Inactive';";
							$resultx=mysqli_query($conn , $sql);
							$result_check=mysqli_num_rows($resultx);
					
							if($result_check <= 0)
							{
								echo '<h4>No Inactive course!</h4>';
							}
							else
							{
								//if result is returned then print it.
								//printing table head
								echo '    <h4>Inactive courses</h4>
											<div class="table-responsive">
												<table class="table">
													<thead>
														<tr>
															
															<th>Name</th>
															<th>Since</th>
															<th>Till</th>
															<th>Catagory</th>
															<th>Actions</th>
														</tr>
													</thead>
													<tbody>';
								//printing results row by row
								while($row = mysqli_fetch_array($resultx, MYSQLI_ASSOC))
								{
								echo '<tr>
		                        <td class="text-center">';
								echo $row['c_name'];
								echo '</td><td>';
								echo $row['c_since'];
								echo '</td><td>';
								echo $row['c_till'];
								echo '</td><td>';
								echo $row['c_catagory'];
								echo '<td>';
		                        echo '<a href="' . $row['c_link'] . '" class="btn-info" target="_blank">Go to course</a> '; 
								echo '</td>
										</tr>';
								}
								echo '</tbody>
										</table>
										</div>';
							
							}
							
						?>