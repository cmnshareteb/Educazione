 <?php 
	include_once 'includes/dbh_inc.php';
	include_once 'header.php';

	if(isset($_SESSION['u_id']))
	{
		$u_id=$_SESSION['u_id'];
	}
	else
	{
		header("Location: index.php");
		exit();
	}
	
	$sql="select * from users where u_id='$u_id';";
	$resultx=mysqli_query($conn , $sql);
	$result_check=mysqli_num_rows($resultx);
	$row = mysqli_fetch_array($resultx, MYSQLI_ASSOC);
	
		if($result_check < 0)
		{
			echo '<h4>No data found!</h4>';
		}
		else
		{
			//if found data then show it to user 
			echo '<div class="wrapper row2">
					<div id="container" class="clear">
						<!-- Main image on page -->
						<h2 class="title">Profile</h2>
						<form action="includes/update_profile.php" method="post" id="user_update_prfile_form">
							<div class="col-sm-4">
							<div class="form-group label-floating">
								<label class="control-label"> first name</label>';
			echo '<input type="text" name="fname" class="form-control" value=' . $row['u_fname'] . '>';
			echo '</div>
					<div class="form-group label-floating">
					<label class="control-label"> last name</label>';
			echo '<input type="text" name="lname" class="form-control" value=' . $row['u_lname'] . '>';
			echo '</div>
					<div class="form-group label-floating">
					<label class="control-label">E-mail ID</label>';
			echo '<input type="text" name="email" class="form-control" value=' . $row['u_email'] . '>';
			echo '</div>';
			echo '<h4>Rank:';
			echo $row['u_rank'];
			echo '</h4>';
			echo '</div>
					</form>
					<button class="btn btn-default btn-lg" form="user_update_prfile_form" name="submit" value="Submit">Save</button>
					</div> 
				</div>
				</div>';
		}

	include_once 'footer.php';
	