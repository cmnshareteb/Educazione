<?php
	include_once 'includes/dbh_inc.php';
	session_start();
	
	echo '<link rel="stylesheet" href="assets/css/bootstrap.min.css" />';
?>	


</style>
	
							<?php

						//running query now
							$sql="select c_name,c_since,c_till,c_catagory,c_status,c_link,i_name from courses c,instructor i,course_by_instructor b where (b.i_id=i.i_id and b.c_id=c.c_id);";
							$resultx=mysqli_query($conn , $sql);
							$result_check=mysqli_num_rows($resultx);
					
							if($result_check <= 0)
							{
								echo '<h4>No course!</h4>';
							}
							else
							{
								//if result is returned then print it.
								//printing table head
								echo '    <h2>All courses</h2>
											<div class="table-responsive">
												<table class="table">
													<thead>
														<tr>
															
															<th>Name</th>
															<th>Since</th>
															<th>Till</th>
															<th>Catagory</th>
															<th>Status</th>
															<th>Instructor</th>
															<th>Actions</th>
														</tr>
													</thead>
													<tbody>';
								//printing results row by row
								while($row = mysqli_fetch_array($resultx, MYSQLI_ASSOC))
								{
								echo '<tr>
		                        <td class="text-center">';
								echo $row['c_name'];
								echo '</td><td>';
								echo $row['c_since'];
								echo '</td><td>';
								echo $row['c_till'];
								echo '</td><td>';
								echo $row['c_catagory'];
								echo '</td><td>';
								echo $row['c_status'];
								echo '</td><td>';
								echo $row['i_name'];
								echo '</td><td>';
		                        echo '<a href="' . $row['c_link'] . '" class="btn-info" target="_blank">Go to course</a> '; 
								echo '</td>
										</tr>';
								}
								echo '</tbody>
										</table>
										</div>';
							
							}
							
						?>