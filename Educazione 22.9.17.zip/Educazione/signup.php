 <?php
	include_once 'header.php';
 ?>
 
 <!--main content-->

 
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Main image on page -->
	<form action="includes/signup_inc.php" method="post" id="user_sign_up_form">
   <div class="col-sm-4">
   <div class="form-group label-floating">
		<label class="control-label">Enter first name</label>
		<input type="text" name="fname" class="form-control">
	</div>
	<div class="form-group label-floating">
		<label class="control-label">Enter last name</label>
		<input type="text" name="lname" class="form-control">
	</div>
	<div class="form-group label-floating">
		<label class="control-label">Enter E-mail ID</label>
		<input type="email" name="email" class="form-control" >
	</div>
	<div class="col-sm-4">
	<div class="form-group label-floating">
		<label class="control-label">Enter Password</label>
		<input type="password" name="passwd" class="form-control">
	</div>
	<div class="form-group label-floating">
		<label class="control-label">Enter Password again</label>
		<input type="password" name="passwd2" class="form-control">
	</div>
	</form>
	<button class="btn btn-default" form="user_sign_up_form" name="submit" value="Submit">Register</button>
</div> 
   </div>
</div>

 
 
 <?php
	include_once 'footer.php';
 ?>