<?php
 session_start();
 
 if(isset($_POST['submit']))
 {
	include_once 'dbh_inc.php';
	
	$first=  mysqli_real_escape_string($conn ,$_POST['fname']);
	$last=   mysqli_real_escape_string($conn ,$_POST['lname']);
	$emailid=  mysqli_real_escape_string($conn ,$_POST['email']);

	
	//error handlers
		//checking for empty fields
	if(empty($first) ||empty($last) ||empty($emailid))
	{
		header("Location: ../profile.php?profile=empty");
		exit();
	}
	else
	{
		//check for input validity
		if(!preg_match("/^[a-zA-z]*$/",$first) ||!preg_match("/^[a-zA-z]*$/",$last) )
		{
			header("Location: ../profile.php?profile=invalid");
			exit();
		}
		else
		{
			//check for email validity
			if (!filter_var($emailid, FILTER_VALIDATE_EMAIL))
			{
				header("Location: ../profile.php?profile=invalidemail");
				exit();
			}
			else
			{
					$u_id=$_SESSION['u_id'];
					$sql="SELECT * FROM users WHERE u_id='$u_id';";
					$result=mysqli_query($conn , $sql);
					$result_check=mysqli_num_rows($result);
					$row = mysqli_fetch_array($resultx, MYSQLI_ASSOC);
					if($result_check >0)
					{
						if(!($first === $row['u_fname']))
						{
							$sql="UPDATE users SET u_fname= '$first' where u_id='$u_id';";
						    $result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
						}
						if(!($last === $row['u_lname']))
						{
							$sql="UPDATE users SET u_fname= '$first' where u_id='$u_id';";
						    $result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
						}
						if(!($emailid === $row['u_email']))
						{
							//check if email already exist
							$sql="SELECT * FROM users WHERE u_email='$emailid';";
							$result=mysqli_query($conn , $sql);
							$result_check=mysqli_num_rows($result);
							if($result_check>0)
							{
								header("Location: ../profile.php?profile=usertaken");
								exit();
							}
							else
							{
								$sql="UPDATE users SET u_email='$emailid' where u_id='$u_id';";
								$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
								//redirect user to profile page again
								header("Location: ../profile.php?profile=success");
								exit();
							}
						}
					}
			
			}
		}
	}
}	
 else
 {
	header("Location: ../profile.php");
	exit();
 }
 
 