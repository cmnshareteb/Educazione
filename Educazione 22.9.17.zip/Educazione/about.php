<?php 
	include_once 'header.php';
?>

 <!--main content-->
<!--Main content-->
<div class="wrapper row2">
  <div id="container" class="clear">
    <!-- Main image on page -->
	<h1>COMING SOON</h1>
    <section id="slider">
		<a href="#"><img src="assets/img/student_home.jpg" height="360" width="960" alt="Educazione"></a>
	</section>
  
    <div id="homepage">
      <!-- services area -->
      <section id="services" class="clear">
        <article class="one_quarter" style="border-style:solid;border-width:3px;">
          <figure><img src="images/demo/32x32.gif" width="32" height="32" alt=""></figure>
          <strong>Data structure</strong>
          <p>Learn data structure to enhance your programm.</p>
          <p class="more"><a href="#">Read More &raquo;</a></p>
        </article>
        <article class="one_quarter" style="border-style:solid;border-width:3px;">
          <figure><img src="images/demo/32x32.gif" width="32" height="32" alt=""></figure>
          <strong>Thoery of computation</strong>
          <p>Learn basic machines and automata to understand compiler basics better.</p>
          <p class="more"><a href="#">Read More &raquo;</a></p>
        </article>
        <article class="one_quarter" style="border-style:solid;border-width:3px;">
          <figure><img src="images/demo/32x32.gif" width="32" height="32" alt=""></figure>
          <strong>Database management system</strong>
          <p>Learn to enhance your application performance,storage.</p>
          <p class="more"><a href="#">Read More &raquo;</a></p>
        </article>
      </section>
    </div>
	</div>
</div>




<?php
	include_once 'footer.php';
?>