<?php
	session_start();
?>

<!Doctype html>
<html lang="en">
	<head>
	<title>Educazione </title>
	<meta charset="UTF-8" >
	
		<!--     Fonts and icons     -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
		
	<link rel="stylesheet" href="assets/css/material-kit.css" />
	<link rel="stylesheet" href="assets/css/layout.css" type="text/css">
	<link href="assets/css/demo.css" rel="stylesheet" />
</head>
<body>

<!-- header -->
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
      <h1><a href="index.php">Educazione</a></h1>
      <h2>Education with ease!</h2>
    </div>
    <nav>
      <ul>
		<?php 
			if(isset($_SESSION['u_id']))
			{
				echo '<li><a href="home.php">Home</a></li>';
			}
			else 
			{
				echo ' <li><a href="index.php">Home</a></li>';
			}
		?>
        
        <li><a href="courses.php">Courses</a></li>
		<?php 
			if(isset($_SESSION['u_id']))
			{
				echo '<li><a href="profile.php">Profile</a></li>';
			}
			else 
			{
				echo '<li><a href="about.php">About</a></li>';
			}
		?>
		
		<?php 
			if(isset($_SESSION['u_id']))
			{
				echo '<li>';
				echo $_SESSION['u_fname'];
				echo '</li>';
			}
		?>
        
		<?php 
			if(isset($_SESSION['u_id']))
			{
				echo '<li class="last"><a href="includes/logout_inc.php">Logout</a></li>';
			}
			else 
			{
				echo ' <li class="last"><a href="login.php">Sign-In/Register</a></li>';
			}
		?>
		
		
       
      </ul>
    </nav>
  </header>
</div>
