<h4>DDL Commands</h4>
<p>	This stands for the Data Definition Language.
    DDL is used to describe the data structure.<br>
	DDL is short name of Data Definition Language, which deals 
	with database schemas and descriptions, 
	of how the data should reside in the database.
</p>
	<ul>
	<li>CREATE- The command is used to create database,table,views,index,etc</li><br>
	<code>CREATE TABLE table_name(col1 datatype,col2 datatype,...);</code><br><br>
	<li>ALTER – alters the structure of the existing database.</li>
	<code>ALTER TABLE table_name ADD column_name datatype;</code><br><br>
	<li>DROP – delete objects from the database.</li>
	<code>DROP TABLE table_name;</code><br><br>
	<li>TRUNCATE – remove all records from a table, including all spaces allocated for the records are removed.</li>
	<code>TRUNCATE TABLE table_name;</code><br>
	</ul>
	These are the basic queries for the DDL.<br>
<p>Follow along with this guided tutorial video.<br>
	See you in next class!!!
</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/brZKyd1sHK4" frameborder="0" allowfullscreen></iframe>