<h2> Welcome to UNIX course.</h2>

<h4>What is UNIX? </h4>
<p> UNIX is a family of multitasking, multiuser computer operating systems that 
    derive from the original AT&T Unix, <br>development starting in the 1970s at the 
	Bell Labs research center by Ken Thompson, Dennis Ritchie, and others.<br>
</p><p>
    Unix was designed to be portable, multi-tasking and multi-user in a time-sharing configuration.
	Unix systems are characterized by various concepts:
	the use of plain text for storing data; 
	a hierarchical file system; treating devices
	and certain types of inter-process communication (IPC) as files;
	and the use of a large number of software tools, 
	small programs that can be strung together through a command-line interpreter using pipes, 
	as opposed to using a single monolithic program that includes all of the same functionality.
	These concepts are collectively known as the "Unix philosophy". 
	Brian Kernighan and Rob Pike summarize this in The Unix Programming Environment as 
	"the idea that the power of a system comes more from the relationships among programs 
	than from the programs themselves".
</p>
<h4>How to UNIX built and evoled</h4>
<p>Follow along with this guided tutorial video.<br>
	See you in next class!!!
</p>
<iframe width="560" height="315" src="https://www.youtube.com/embed/DpcCtaaGxyQ" frameborder="0" allowfullscreen></iframe>