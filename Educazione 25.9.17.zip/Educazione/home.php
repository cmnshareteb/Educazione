<?php
	include_once 'header.php';
	include_once 'includes/dbh_inc.php';
	
	if(isset($_SESSION['u_id']))
	{
		$u_id=$_SESSION['u_id'];
	}
	else
	{
		header("Location: index.php");
		exit();
	}
?>

<div class="row" style="background-color:#ffffff;">
  <div id="container" class="row">
    <!-- Main image on page -->

    
	<div id="content" style="width: 300px;">
          <aside id="left_column">
      <h2 class="title">Home</h2>
      <nav>
        <ul class="list-group">
          <li><a href="enrolled.php" target="iframe_a" class="list-group-item">Enrolled courses</a></li>
          <li><a href="active.php" target="iframe_a" class="list-group-item">Active courses</a></li>
          <li><a href="inactive.php" target="iframe_a" class="list-group-item">Inactive courses</a></li>
          <li class="last"><a href="result.php" target="iframe_a" class="list-group-item">Completed courses/Result</a></li>
        </ul>
      </nav>
    </div>

	<div style="height:59px;"></div>

	<div class="col-md- col-md-offset-1">
	<!--the iframe will contain the result of all the queries of enrolled,active,inactive-->
	<iframe src="enrolled.php" name="iframe_a" style="border:none;" height="800" width="650"></iframe>

	
   <!--main ends-->
   </div>
   </div>
</div>

<?php
	include_once 'footer.php';
?>