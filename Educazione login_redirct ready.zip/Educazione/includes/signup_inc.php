 <?php
 
 if(isset($_POST['submit']))
 {
	include_once 'dbh_inc.php';
	
	$first=  mysqli_real_escape_string($conn ,$_POST['fname']);
	$last=   mysqli_real_escape_string($conn ,$_POST['lname']);
	$emailid=  mysqli_real_escape_string($conn ,$_POST['email']);
	$passwd1=mysqli_real_escape_string($conn ,$_POST['passwd']);
	$passwd2=mysqli_real_escape_string($conn ,$_POST['passwd2']);
	
	//error handlers
		//checking for empty fields
	if(empty($first) ||empty($last) ||empty($emailid) ||empty($passwd1) ||empty($passwd2))
	{
		header("Location: ../signup.php?signup=empty");
		exit();
	}
	else
	{
		//check for input validity
		if(!preg_match("/^[a-zA-z]*$/",$first) ||!preg_match("/^[a-zA-z]*$/",$last) )
		{
			header("Location: ../signup.php?signup=invalid");
			exit();
		}
		else
		{
			//check for email validity
			if (!filter_var($emailid, FILTER_VALIDATE_EMAIL))
			{
				header("Location: ../signup.php?signup=invalidemail");
				exit();
			}
			else
			{
				if(!($passwd1===$passwd2))
				{
					header("Location: ../signup.php?signup=invalidpasswd");
					exit();
				}
				else
				{
					$sql="SELECT * FROM users WHERE u_email='$emailid';";
					$result=mysqli_query($conn , $sql);
					$result_check=mysqli_num_rows($result);
					
					if($result_check >0)
					{
						header("Location: ../signup.php?signup=usertaken");
						exit();
					}
					else
					{
						//hashing passwd for security
						//$hased_passwd=password_hash($passwd1,PASSWORD_DEFAULT);
						$hased_passwd=$passwd1; //testing
						//inserting user into database
						$sql="insert into users (u_fname,u_lname,u_email,u_password) values ('$first','$last','$emailid','$hased_passwd');";
						$result=mysqli_query($conn , $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error(), E_USER_ERROR);
						//redirect user to signup page again
						header("Location: ../signup.php?signup=success");
						exit();
					
					}
				}
			}
		}
	}
}	
 else
 {
	header("Location: ../signup.php");
	exit();
 }
 
 