<?php 

session_start();

if(isset($_POST['submit']))
{
	include_once 'dbh_inc.php';

$emailid=mysqli_real_escape_string($conn ,$_POST['email']);
$passwd =mysqli_real_escape_string($conn ,$_POST['password']);

	if(empty($emailid) || empty($passwd))
	{
		header("Location: ../login.php?login=empty");
		exit();
	}
	else
	{
		$sql = "SELECT * FROM users WHERE u_email='$emailid'";
		$result = mysqli_query($conn, $sql);
		$resultCheck = mysqli_num_rows($result);
		
		if($resultCheck < 1)
		{
			header("Location: ../login.php?login=errorntfnd");
			exit();
		}
		else
		{
			if($row = mysqli_fetch_assoc($result))
			{
			//hashing not working 
				$hashed_pwd_check=password_verify($passwd,$row["u_password"]);
				
				$hashedPwd = password_hash($passwd, PASSWORD_DEFAULT);
				//temp
				if($passwd === $row['u_password'])
				{
					//Log in the user here
					$_SESSION['u_id'] = $row['u_id'];
					$_SESSION['u_fname'] = $row['u_fname'];
					$_SESSION['u_lname'] = $row['u_lname'];
					$_SESSION['u_email'] = $row['u_email'];
				
					header("Location: ../home.php?login=success");
					exit();
				}
				elseif($hashed_pwd_check == false)
				{
					header("Location: ../login.php?login=errorpwd");
					exit();
				}
			}
			else 
			{
			
			}
		}
		
	}
}
else
{
	header("Location: ../login.php?login=error");
	exit();
}