
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left">Copyrights reserved by <a href="#">educazione</a></p>
    <p class="fl_right">Handcrafted with Love.</p>
  </footer>
</div>

</body>
</html>