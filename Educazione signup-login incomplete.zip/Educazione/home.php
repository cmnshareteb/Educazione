<?php
	include_once 'header.php';
?>

<div class="row" style="background-color:#ffffff;">
  <div id="container" class="row">
    <!-- Main image on page -->

    
	<div id="content" style="width: 300px;">
          <aside id="left_column">
      <h2 class="title">Home</h2>
      <nav>
        <ul>
          <li><a href="#">Enrolled courses</a></li>
          <li><a href="#">Active courses</a></li>
          <li><a href="#">Inactive courses</a></li>
          <li class="last"><a href="#">Completed courses</a></li>
        </ul>
      </nav>
    </div>

	<div style="height:59px;"></div>

	<div class="col-md- col-md-offset-1">
	<span>
			        <h4>Simple Table with Actions</h4>
		        <div class="table-responsive">
		            <table class="table">
		                <thead>
		                    <tr>
		                        <th class="text-center">#</th>
		                        <th>Name</th>
		                        <th>Job Position</th>
		                        <th>Since</th>
		                        <th class="text-right">Salary</th>
		                        <th class="text-right">Actions</th>
		                    </tr>
		                </thead>
		                <tbody>
		                    <tr>
		                        <td class="text-center">1</td>
		                        <td>Andrew Mike</td>
		                        <td>Develop</td>
		                        <td>2013</td>
		                        <td class="text-right">&euro; 99,225</td>
		                        <td class="td-actions text-right">
		                            <button type="button" rel="tooltip" title="View Profile" class="btn btn-info btn-simple btn-xs">
		                                <i class="fa fa-user"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Edit Profile" class="btn btn-success btn-simple btn-xs">
		                                <i class="fa fa-edit"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-simple btn-xs">
		                                <i class="fa fa-times"></i>
		                            </button>
		                        </td>
		                    </tr>
		                    <tr>
		                        <td class="text-center">2</td>
		                        <td>John Doe</td>
		                        <td>Design</td>
		                        <td>2012</td>
		                        <td class="text-right">&euro; 89,241</td>
		                        <td class="td-actions text-right">
		                            <button type="button" rel="tooltip" title="View Profile" class="btn btn-info btn-simple btn-xs">
		                                <i class="fa fa-user"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Edit Profile" class="btn btn-success btn-simple btn-xs">
		                                <i class="fa fa-edit"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-simple btn-xs">
		                                <i class="fa fa-times"></i>
		                            </button>
		                        </td>
		                    </tr>
		                    <tr>
		                        <td class="text-center">3</td>
		                        <td>Alex Mike</td>
		                        <td>Design</td>
		                        <td>2010</td>
		                        <td class="text-right">&euro; 92,144</td>
		                        <td class="td-actions text-right">
		                            <button type="button" rel="tooltip" title="View Profile" class="btn btn-info btn-simple btn-xs">
		                                <i class="fa fa-user"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Edit Profile" class="btn btn-success btn-simple btn-xs">
		                                <i class="fa fa-edit"></i>
		                            </button>
		                            <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-simple btn-xs">
		                                <i class="fa fa-times"></i>
		                            </button>
		                        </td>
		                    </tr>
		                </tbody>
		            </table>
		            </div>
   <!--main ends-->
   </div>
   </div>
</div>

<?php
	include_once 'footer.php';
?>