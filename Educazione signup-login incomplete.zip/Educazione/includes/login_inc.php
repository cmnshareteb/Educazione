<?php

if(isset($_POST['submit']))
{
	include_once 'dbh_inc.php';

	
	$emailid=  mysqli_real_escape_string($conn ,$_POST['email']);
	$passwd=  mysqli_real_escape_string($conn ,$_POST['password']);
	
	//error handlers
		//checking for empty fields
	if(empty($emailid) ||empty($passwd))
	{
		header("Location: ../login.php?login=empty");
		exit();
	}
	else
	{
		$sql="SELECT * FROM users WHERE u_email='$emailid';";
		$result=mysqli_query($conn ,$sql);
		$result_check=mysqli_num_rows($result);
				
			if($result_check <1)
			{
				header("Location: ../login.php?login=errormail");
				exit();
			}
			else
			{
				if($row=mysqli_fetch_assoc($result))
				{
					//de-hashing password
					
					$hashed_pwd_check= password_verify($passwd,$row['u_password']);
					
					if($hashed_pwd_check == false)
					{
						header("Location: ../login.php?login=errorpasswd");
						exit();
					}
					elseif($hashed_pwd_check == true)
					{
						//login user here
						$_SESSION['u_id']=$row['u_id'];
						$_SESSION['u_fname']=$row['u_fname'];
						$_SESSION['u_lname']=$row['u_lname'];
						$_SESSION['u_email']=$row['u_email'];
						$_SESSION['u_password']=$row['u_password'];
						
						header("Location: ../login.php?login=success");
						exit();
						
					}
				}
				
			}
	}
}
 else
 {
	header("Location: ../login.php?login=error");
	exit();
 }
 
 