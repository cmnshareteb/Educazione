create database educazione;

create table users(u_id int NOT NULL AUTO_INCREMENT PRIMARY KEY,u_fname varchar(20) not null,u_lname varchar(20) not null,u_email varchar(50) not null,u_password varchar(50) not null);

